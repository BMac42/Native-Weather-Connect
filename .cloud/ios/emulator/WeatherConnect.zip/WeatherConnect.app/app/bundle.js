require("./runtime.js");require("./vendor.js");module.exports =
(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["bundle"],{

/***/ "../$$_lazy_route_resource lazy recursive":
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "../$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./app.css":
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {global.registerModule("~@nativescript/theme/css/core.css", () => __webpack_require__("../node_modules/nativescript-dev-webpack/css2json-loader.js?useForImports!../node_modules/@nativescript/theme/css/core.css"));
global.registerModule("@nativescript/theme/css/core.css", () => __webpack_require__("../node_modules/nativescript-dev-webpack/css2json-loader.js?useForImports!../node_modules/@nativescript/theme/css/core.css"));
global.registerModule("~@nativescript/theme/css/blue.css", () => __webpack_require__("../node_modules/nativescript-dev-webpack/css2json-loader.js?useForImports!../node_modules/@nativescript/theme/css/blue.css"));
global.registerModule("@nativescript/theme/css/blue.css", () => __webpack_require__("../node_modules/nativescript-dev-webpack/css2json-loader.js?useForImports!../node_modules/@nativescript/theme/css/blue.css"));module.exports = {"type":"stylesheet","stylesheet":{"rules":[{"type":"import","import":"\"~@nativescript/theme/css/core.css\""},{"type":"import","import":"\"~@nativescript/theme/css/blue.css\""},{"type":"comment","comment":" Place any CSS rules you want to apply on both iOS and Android here.\nThis is where the vast majority of your CSS code goes. "}],"parsingErrors":[]}};;
    if (true) {
        module.hot.accept();
        module.hot.dispose(() => {
            global.hmrRefresh({ type: 'style', path: './app.css' });
        })
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/nativescript-dev-webpack/node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./app/app.component.html":
/***/ (function(module, exports) {

module.exports = "<!-- https://docs.nativescript.org/angular/core-concepts/angular-navigation.html#page-router-outlet -->\n<page-router-outlet></page-router-outlet>\n<Label text=\"main view works\"></Label>\n<!-- <StackLayout>\n<app-main></app-main>\n</StackLayout> -->\n"

/***/ }),

/***/ "./app/app.component.tns.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var AppComponent = /** @class */ (function () {
    function AppComponent() {
    }
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__("./app/app.component.html"),
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./app/app.module.tns.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _src_app_app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("./app/app.component.tns.ts");
/* harmony import */ var _src_app_main_main_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("./app/main/main.component.ts");
/* harmony import */ var _src_app_pre_loader_pre_loader_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("./app/pre-loader/pre-loader.component.ts");
/* harmony import */ var _src_app_main_detailed_detailed_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("./app/main/detailed/detailed.component.ts");
/* harmony import */ var _src_app_skycon_skycon_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("./app/skycon/skycon.component.ts");
/* harmony import */ var _src_app_main_week_week_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("./app/main/week/week.component.ts");
/* harmony import */ var _src_app_main_week_week_model__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("./app/main/week/week.model.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};











// Uncomment and add to NgModule imports if you need to use two-way binding
// import { NativeScriptFormsModule } from 'nativescript-angular/forms';
// Uncomment and add to NgModule imports  if you need to use the HTTP wrapper
// import { NativeScriptHttpClientModule } from 'nativescript-angular/http-client';
var AppModule = /** @class */ (function () {
    /*
    Pass your application module to the bootstrapModule function located in main.ts to start your app
    */
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [
                _src_app_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"],
                _src_app_main_main_component__WEBPACK_IMPORTED_MODULE_5__["MainComponent"],
                _src_app_pre_loader_pre_loader_component__WEBPACK_IMPORTED_MODULE_6__["PreLoaderComponent"],
                _src_app_main_detailed_detailed_component__WEBPACK_IMPORTED_MODULE_7__["DetailedComponent"],
                _src_app_skycon_skycon_component__WEBPACK_IMPORTED_MODULE_8__["SkyconComponent"],
                _src_app_main_week_week_component__WEBPACK_IMPORTED_MODULE_9__["WeekComponent"],
                _src_app_main_week_week_model__WEBPACK_IMPORTED_MODULE_10__["WeekObjectComponent"]
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClientModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
            ],
            providers: [],
            bootstrap: [_src_app_app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"]],
            schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NO_ERRORS_SCHEMA"]]
        })
        /*
        Pass your application module to the bootstrapModule function located in main.ts to start your app
        */
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./app/main/detailed/detailed.component.html":
/***/ (function(module, exports) {

module.exports = "<StackLayout>\n  <Label text=\"detailed works\" textWrap=\"true\"></Label>\n  <Label text=\"This is a migrated component\" textWrap=\"true\"></Label>\n  <Label text=\"Update it to provide the UI elements required in your mobile app\" textWrap=\"true\"></Label>\n</StackLayout>\n\n<!--\nOriginal Web template:\n\n\n<div class=\"container\">\n  <div class=\"today-head\">\n    <h2 class=\"text-center\">Conditions for {{todayDate | date:'MMMM dd, yyyy'}}</h2>\n    <p class=\"text-center\">{{dailyWeather.daily.data[0].summary}}</p>\n  </div>\n  <div class=\"today-conditions\">\n    <div class=\"condition-block\">\n      <h4>High / Low</h4>\n      <div class=\"temp\">\n        <p>{{dailyWeather.daily.data[0].temperatureHigh | number:'1.0-0'}}&#176;</p>\n        <i class=\"fas fa-arrow-up\"></i>\n        <p> / </p>\n        <p>{{dailyWeather.daily.data[0].temperatureLow | number:'1.0-0'}}&#176;</p>\n        <i class=\"fas fa-arrow-down\"></i>\n    </div>\n  </div>\n  <div class=\"condition-block\">\n    <h4>Precip %</h4>\n    <p>{{dailyWeather.daily.data[0].precipProbability | percent}}</p>\n  </div>\n  <div class=\"condition-block\">\n    <h4>Humidity</h4>\n    <p>{{dailyWeather.daily.data[0].humidity | percent}}</p>\n  </div>\n  <div class=\"condition-block\">\n    <h4>UV Index</h4>\n    <p>{{dailyWeather.daily.data[0].uvIndex}}</p>\n  </div>\n  </div>\n  <app-week\n  [weekWeather]='dailyWeather'>\n  </app-week>\n</div>\n\n-->"

/***/ }),

/***/ "./app/main/detailed/detailed.component.scss":
/***/ (function(module, exports) {

module.exports = "/*\nAdd your NativeScript specific styles here.\nTo learn more about styling in NativeScript see:\nhttps://docs.nativescript.org/angular/ui/styling\n*/\n"

/***/ }),

/***/ "./app/main/detailed/detailed.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailedComponent", function() { return DetailedComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var DetailedComponent = /** @class */ (function () {
    function DetailedComponent() {
        this.todayGraph = false;
    }
    DetailedComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], DetailedComponent.prototype, "dailyWeather", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], DetailedComponent.prototype, "detailLat", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Number)
    ], DetailedComponent.prototype, "detailLng", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], DetailedComponent.prototype, "todayDate", void 0);
    DetailedComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-detailed',
            template: __webpack_require__("./app/main/detailed/detailed.component.html"),
            styles: [__webpack_require__("./app/main/detailed/detailed.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], DetailedComponent);
    return DetailedComponent;
}());



/***/ }),

/***/ "./app/main/main.component.html":
/***/ (function(module, exports) {

module.exports = "<StackLayout>\n  <Label text=\"main works\" textWrap=\"true\"></Label>\n  <Label text=\"This is a migrated component\" textWrap=\"true\"></Label>\n  <Label text=\"Update it to provide the UI elements required in your mobile app\" textWrap=\"true\"></Label>\n</StackLayout>\n\n"

/***/ }),

/***/ "./app/main/main.component.scss":
/***/ (function(module, exports) {

module.exports = "/*\nAdd your NativeScript specific styles here.\nTo learn more about styling in NativeScript see:\nhttps://docs.nativescript.org/angular/ui/styling\n*/\n"

/***/ }),

/***/ "./app/main/main.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MainComponent", function() { return MainComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/services/skycons.service.ts");
/* harmony import */ var _src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("./app/services/api.service.ts");
/* harmony import */ var _angular_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("../node_modules/@angular/animations/fesm5/animations.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var MainComponent = /** @class */ (function () {
    function MainComponent(skycons, apiService) {
        this.skycons = skycons;
        this.apiService = apiService;
        this.showToday = true;
        this.currentSummary = '';
        this.expand = false;
        this.getId = '#sky';
    }
    MainComponent.prototype.ngOnInit = function () {
        var _this = this;
        // get date
        this.currentDate = new Date();
        // get weather from coords
        this.apiService.getWeather(this.finalLat, this.finalLng)
            .subscribe(function (res) {
            _this.weather = res;
            // print darksky api get in console
            _this.weatherIcon = _this.weather.currently.icon.replace(/-/g, '_').toUpperCase();
            // get temp
            _this.currentTemp = _this.weather.currently.apparentTemperature.toString().slice(0, 2);
            // get summary
            _this.currentSummary = _this.weather.daily.data[0].summary;
        });
    };
    MainComponent.prototype.isExpand = function () {
        this.expand = !this.expand;
        this.showToday = !this.showToday;
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], MainComponent.prototype, "finalLat", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], MainComponent.prototype, "finalLng", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], MainComponent.prototype, "city", void 0);
    MainComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-main',
            template: __webpack_require__("./app/main/main.component.html"),
            styles: [__webpack_require__("./app/main/main.component.scss")],
            animations: [
                Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["trigger"])('expandShrink', [
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('expand', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        height: '800px',
                        width: '90%',
                    })),
                    // state('shrink', style({
                    //   height: '500px',
                    //   width: '65%',
                    // })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('expandFlip', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        transform: 'rotate(180deg)',
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["state"])('shrinkFlip', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
                        transform: 'rotate(0deg)'
                    })),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('expand => shrink', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])(300)),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('shrink => expand', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])(300)),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('expandFlip => shrinkFlip', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])(300)),
                    Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])('shrinkFlip => expandFlip', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])(1000)),
                ]),
            ]
        }),
        __metadata("design:paramtypes", [_src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__["SkyconsService"], _src_app_services_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]])
    ], MainComponent);
    return MainComponent;
}());



/***/ }),

/***/ "./app/main/week/week-model.html":
/***/ (function(module, exports) {

module.exports = "<div class=\"week-container\">\n  <div class=\"week-item-container\" *ngFor=\"let dateItem of date; let i = index\">\n    <p class=\"date text-center\">{{date[i] | date:'EEEE'}}</p>\n    <p class=\"date text-center\">{{date[i] | date:'MMMM dd, yyyy'}}</p>\n    <app-skycon *ngIf='icon' [icon]=\"icon[i]\" [id]=\"'#sky-' + i\">\n    </app-skycon>\n    <p class=\"text-center\">High / Low</p>\n    <div class=\"temp-flex\">\n      <p class=\"temp\">{{hi[i] | number:'1.0-0'}}&#176;</p>\n      <p class=\"temp\">{{low[i] | number:'1.0-0'}}&#176;</p>\n    </div>\n  </div>\n</div>\n\n\n"

/***/ }),

/***/ "./app/main/week/week.component.html":
/***/ (function(module, exports) {

module.exports = "<StackLayout>\n  <Label text=\"week works\" textWrap=\"true\"></Label>\n  <Label text=\"This is a migrated component\" textWrap=\"true\"></Label>\n  <Label text=\"Update it to provide the UI elements required in your mobile app\" textWrap=\"true\"></Label>\n</StackLayout>\n\n<!--\nOriginal Web template:\n\n<div class=\"week-wrapper\">\n  <h2>5 Day Forecast</h2>\n    <app-week-model\n    [date]='days'\n    [hi]='daysTempHi'\n    [low]='daysTempLow'\n    [icon]='daysIcon'\n    >\n  </app-week-model>\n</div>\n\n-->"

/***/ }),

/***/ "./app/main/week/week.component.scss":
/***/ (function(module, exports) {

module.exports = "/*\nAdd your NativeScript specific styles here.\nTo learn more about styling in NativeScript see:\nhttps://docs.nativescript.org/angular/ui/styling\n*/\n"

/***/ }),

/***/ "./app/main/week/week.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WeekComponent", function() { return WeekComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var daysObject = [1, 2, 3, 4, 5];
var WeekComponent = /** @class */ (function () {
    function WeekComponent() {
        var _this = this;
        this.days = daysObject.map(function (i) { return _this.weekDates(i); });
    }
    /* check if weekWeather @Input is loaded in component (is undefined when called in constructor) */
    WeekComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.weekWeather) {
            this.daysTempHi = daysObject.map(function (_) { return _this.weekTempHi(_); });
            this.daysTempLow = daysObject.map(function (_) { return _this.weekTempLow(_); });
            this.daysIcon = daysObject.map(function (_) { return _this.weekIcon(_); });
        }
    };
    WeekComponent.prototype.weekDates = function (day) {
        this.date = new Date();
        this.date.setDate(this.date.getDate() + day);
        return this.day = this.date;
    };
    WeekComponent.prototype.weekTempHi = function (day) {
        return this.weekWeather.daily.data[day].apparentTemperatureHigh;
    };
    WeekComponent.prototype.weekTempLow = function (day) {
        return this.weekWeather.daily.data[day].apparentTemperatureLow;
    };
    WeekComponent.prototype.weekIcon = function (day) {
        return this.weekWeather.daily.data[day].icon.replace(/-/g, '_').toUpperCase();
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], WeekComponent.prototype, "weekWeather", void 0);
    WeekComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-week',
            template: __webpack_require__("./app/main/week/week.component.html"),
            styles: [__webpack_require__("./app/main/week/week.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], WeekComponent);
    return WeekComponent;
}());



/***/ }),

/***/ "./app/main/week/week.model.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WeekObjectComponent", function() { return WeekObjectComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/services/skycons.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var WeekObjectComponent = /** @class */ (function () {
    function WeekObjectComponent(skycons) {
        this.skycons = skycons;
        // this.date = date;
        // this.hi = hi;
        // this.low = low;
        // this.icon = icon;
    }
    WeekObjectComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], WeekObjectComponent.prototype, "date", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], WeekObjectComponent.prototype, "hi", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], WeekObjectComponent.prototype, "low", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Array)
    ], WeekObjectComponent.prototype, "icon", void 0);
    WeekObjectComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-week-model',
            template: __webpack_require__("./app/main/week/week-model.html"),
            styles: [__webpack_require__("./app/main/week/week.component.scss")]
        }),
        __metadata("design:paramtypes", [_src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__["SkyconsService"]])
    ], WeekObjectComponent);
    return WeekObjectComponent;
}());



/***/ }),

/***/ "./app/pre-loader/pre-loader.component.html":
/***/ (function(module, exports) {

module.exports = "<StackLayout>\n  <Label text=\"pre-loader works\" textWrap=\"true\"></Label>\n  <Label text=\"This is a migrated component\" textWrap=\"true\"></Label>\n  <Label text=\"Update it to provide the UI elements required in your mobile app\" textWrap=\"true\"></Label>\n</StackLayout>\n\n<!--\nOriginal Web template:\n\n<div class=\"loader\">Getting Weather...</div>\n-->"

/***/ }),

/***/ "./app/pre-loader/pre-loader.component.scss":
/***/ (function(module, exports) {

module.exports = "/*\nAdd your NativeScript specific styles here.\nTo learn more about styling in NativeScript see:\nhttps://docs.nativescript.org/angular/ui/styling\n*/\n"

/***/ }),

/***/ "./app/pre-loader/pre-loader.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreLoaderComponent", function() { return PreLoaderComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var PreLoaderComponent = /** @class */ (function () {
    function PreLoaderComponent() {
        this.loadCheck = true;
    }
    PreLoaderComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], PreLoaderComponent.prototype, "loadCheck", void 0);
    PreLoaderComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-pre-loader',
            template: __webpack_require__("./app/pre-loader/pre-loader.component.html"),
            styles: [__webpack_require__("./app/pre-loader/pre-loader.component.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], PreLoaderComponent);
    return PreLoaderComponent;
}());



/***/ }),

/***/ "./app/services/api.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("../node_modules/rxjs/_esm5/operators/index.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var ApiService = /** @class */ (function () {
    function ApiService(http) {
        this.http = http;
    }
    // getGoogle(lat, lng) {
    //   return this.http.get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=AIzaSyBAQ09H6mx4rW10kArm5nRpn-IPUqXLZMg`)
    //     .pipe(map((res) => res));
    // }
    ApiService.prototype.getWeather = function (lat, lng) {
        return this.http.get("https://cors-anywhere.herokuapp.com/https://api.darksky.net/forecast/58dc7954c2a0728421d68a3a89f3dc55/" + lat + "," + lng)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(function (res) { return res; }));
    };
    ApiService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]])
    ], ApiService);
    return ApiService;
}());



/***/ }),

/***/ "./app/services/skycons.service.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkyconsService", function() { return SkyconsService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var skycons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("../node_modules/skycons/skycons.js");
/* harmony import */ var skycons__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(skycons__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var Skycons = new skycons__WEBPACK_IMPORTED_MODULE_1___default.a({});
var SkyconsService = /** @class */ (function () {
    function SkyconsService() {
        this.functions = new Skycons({ color: 'white' });
        this.constants = Skycons;
    }
    SkyconsService.prototype.getIcon = function (icon) {
        return icon;
    };
    SkyconsService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [])
    ], SkyconsService);
    return SkyconsService;
}());



/***/ }),

/***/ "./app/skycon/skycon.component.html":
/***/ (function(module, exports) {

module.exports = "<StackLayout>\n  <Label text=\"skycon works\" textWrap=\"true\"></Label>\n  <Label text=\"This is a migrated component\" textWrap=\"true\"></Label>\n  <Label text=\"Update it to provide the UI elements required in your mobile app\" textWrap=\"true\"></Label>\n</StackLayout>\n\n<!--\nOriginal Web template:\n\n\n<canvas id=\"{{id}}\" height=\"300\" width=\"300\"></canvas>\n\n\n\n-->"

/***/ }),

/***/ "./app/skycon/skycon.component.scss":
/***/ (function(module, exports) {

module.exports = "/*\nAdd your NativeScript specific styles here.\nTo learn more about styling in NativeScript see:\nhttps://docs.nativescript.org/angular/ui/styling\n*/\n"

/***/ }),

/***/ "./app/skycon/skycon.component.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkyconComponent", function() { return SkyconComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/services/skycons.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var daysObject = [1, 2, 3, 4, 5];
var SkyconComponent = /** @class */ (function () {
    function SkyconComponent(skycons) {
        this.skycons = skycons;
    }
    SkyconComponent.prototype.ngOnInit = function () {
        var _this = this;
        setTimeout(function () {
            _this.skycons.functions.add(_this.id, _this.skycons.getIcon(_this.icon));
            _this.skycons.functions.play();
        }, .1);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", String)
    ], SkyconComponent.prototype, "icon", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Object)
    ], SkyconComponent.prototype, "id", void 0);
    SkyconComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-skycon',
            template: __webpack_require__("./app/skycon/skycon.component.html"),
            styles: [__webpack_require__("./app/skycon/skycon.component.scss")]
        }),
        __metadata("design:paramtypes", [_src_app_services_skycons_service__WEBPACK_IMPORTED_MODULE_1__["SkyconsService"]])
    ], SkyconComponent);
    return SkyconComponent;
}());



/***/ }),

/***/ "./main.tns.ts":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony import */ var nativescript_angular_platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("../node_modules/@nativescript/angular/platform.js");
/* harmony import */ var nativescript_angular_platform__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(nativescript_angular_platform__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_app_app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/app.module.tns.ts");

            __webpack_require__("../node_modules/nativescript-dev-webpack/load-application-css-angular.js")();
            
            
        if (true) {
            const hmrUpdate = __webpack_require__("../node_modules/nativescript-dev-webpack/hmr/index.js").hmrUpdate;
            global.__coreModulesLiveSync = global.__onLiveSync;

            global.__onLiveSync = function () {
                // handle hot updated on LiveSync
                hmrUpdate();
            };

            global.hmrRefresh = function({ type, path } = {}) {
                // the hot updates are applied, ask the modules to apply the changes
                setTimeout(() => {
                    global.__coreModulesLiveSync({ type, path });
                });
            };

            // handle hot updated on initial app start
            hmrUpdate();
        }
        
            
        __webpack_require__("../node_modules/@nativescript/core/bundle-entry-points.js");
        

var options_Generated = {};

if (true) {
    options_Generated = {
        hmrOptions: {
            moduleTypeFactory: function () { return __webpack_require__("./app/app.module.tns.ts").AppModule; },
            livesyncCallback: function (platformReboot) { setTimeout(platformReboot, 0); }
        }
    };
}

if (true) {
    module["hot"].accept(["./app/app.module.tns.ts"], function(__WEBPACK_OUTDATED_DEPENDENCIES__) { /* harmony import */ _src_app_app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("./app/app.module.tns.ts");
(function () {
        global["hmrRefresh"]({});
    })(__WEBPACK_OUTDATED_DEPENDENCIES__); });
}
// A traditional NativeScript application starts by initializing global objects,
// setting up global CSS rules, creating, and navigating to the main page.
// Angular applications need to take care of their own initialization: modules, components, directives, routes, DI providers.
// A NativeScript Angular app needs to make both paradigms work together,
// so we provide a wrapper platform object, platformNativeScriptDynamic,
// that sets up a NativeScript application and can bootstrap the Angular framework.
nativescript_angular_platform__WEBPACK_IMPORTED_MODULE_0__["platformNativeScriptDynamic"](Object.assign({}, options_Generated)).bootstrapModule(_src_app_app_module__WEBPACK_IMPORTED_MODULE_1__["AppModule"]);

    
        
        
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("../node_modules/nativescript-dev-webpack/node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./package.json":
/***/ (function(module) {

module.exports = {"main":"main.tns.js","android":{"v8Flags":"--expose_gc","markingMode":"none"}};

/***/ })

},[["./main.tns.ts","runtime","vendor"]]]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi4vJF9sYXp5X3JvdXRlX3Jlc291cmNlIGxhenkgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly8vLi9hcHAuY3NzIiwid2VicGFjazovLy8uL2FwcC9hcHAuY29tcG9uZW50Lmh0bWwiLCJ3ZWJwYWNrOi8vLy4vYXBwL2FwcC5jb21wb25lbnQudG5zLnRzIiwid2VicGFjazovLy8uL2FwcC9hcHAubW9kdWxlLnRucy50cyIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi9kZXRhaWxlZC9kZXRhaWxlZC5jb21wb25lbnQuaHRtbCIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi9kZXRhaWxlZC9kZXRhaWxlZC5jb21wb25lbnQuc2NzcyIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi9kZXRhaWxlZC9kZXRhaWxlZC5jb21wb25lbnQudHMiLCJ3ZWJwYWNrOi8vLy4vYXBwL21haW4vbWFpbi5jb21wb25lbnQuaHRtbCIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi9tYWluLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy8uL2FwcC9tYWluL21haW4uY29tcG9uZW50LnRzIiwid2VicGFjazovLy8uL2FwcC9tYWluL3dlZWsvd2Vlay1tb2RlbC5odG1sIiwid2VicGFjazovLy8uL2FwcC9tYWluL3dlZWsvd2Vlay5jb21wb25lbnQuaHRtbCIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi93ZWVrL3dlZWsuY29tcG9uZW50LnNjc3MiLCJ3ZWJwYWNrOi8vLy4vYXBwL21haW4vd2Vlay93ZWVrLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly8vLi9hcHAvbWFpbi93ZWVrL3dlZWsubW9kZWwudHMiLCJ3ZWJwYWNrOi8vLy4vYXBwL3ByZS1sb2FkZXIvcHJlLWxvYWRlci5jb21wb25lbnQuaHRtbCIsIndlYnBhY2s6Ly8vLi9hcHAvcHJlLWxvYWRlci9wcmUtbG9hZGVyLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy8uL2FwcC9wcmUtbG9hZGVyL3ByZS1sb2FkZXIuY29tcG9uZW50LnRzIiwid2VicGFjazovLy8uL2FwcC9zZXJ2aWNlcy9hcGkuc2VydmljZS50cyIsIndlYnBhY2s6Ly8vLi9hcHAvc2VydmljZXMvc2t5Y29ucy5zZXJ2aWNlLnRzIiwid2VicGFjazovLy8uL2FwcC9za3ljb24vc2t5Y29uLmNvbXBvbmVudC5odG1sIiwid2VicGFjazovLy8uL2FwcC9za3ljb24vc2t5Y29uLmNvbXBvbmVudC5zY3NzIiwid2VicGFjazovLy8uL2FwcC9za3ljb24vc2t5Y29uLmNvbXBvbmVudC50cyIsIndlYnBhY2s6Ly8vLi9tYWluLnRucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEVBQUU7QUFDRjtBQUNBLDRDQUE0QyxXQUFXO0FBQ3ZEO0FBQ0E7QUFDQSx5RTs7Ozs7OztBQ1pBLCtHQUFpRSxtQkFBTyxDQUFDLDRIQUEwRjtBQUNuSyxnRUFBZ0UsbUJBQU8sQ0FBQyw0SEFBMEY7QUFDbEssaUVBQWlFLG1CQUFPLENBQUMsNEhBQTBGO0FBQ25LLGdFQUFnRSxtQkFBTyxDQUFDLDRIQUEwRixHQUFHLGtCQUFrQixrQ0FBa0MsVUFBVSxpRUFBaUUsRUFBRSxpRUFBaUUsRUFBRSwySkFBMko7QUFDcGdCLFFBQVEsSUFBVTtBQUNsQjtBQUNBO0FBQ0EsK0JBQStCLG1DQUFtQztBQUNsRSxTQUFTO0FBQ1Q7Ozs7Ozs7OztBQ1RBLGdSOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0EwQztBQU8xQztJQUFBO0lBQTRCLENBQUM7SUFBaEIsWUFBWTtRQUx4QiwrREFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLFVBQVU7O1NBRXJCLENBQUM7T0FFVyxZQUFZLENBQUk7SUFBRCxtQkFBQztDQUFBO0FBQUo7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQa0M7QUFFWjtBQUNXO0FBQ0Y7QUFFRjtBQUNPO0FBQ2lCO0FBQ0E7QUFDWDtBQUNEO0FBQ0U7QUFHcEUsMkVBQTJFO0FBQzNFLHdFQUF3RTtBQUV4RSw2RUFBNkU7QUFDN0UsbUZBQW1GO0FBd0JuRjtJQUhBOztNQUVFO0lBQ0Y7SUFBeUIsQ0FBQztJQUFiLFNBQVM7UUF0QnJCLDhEQUFRLENBQUM7WUFDUixZQUFZLEVBQUU7Z0JBQ1osbUVBQVk7Z0JBQ1osMEVBQWE7Z0JBQ2IsMkZBQWtCO2dCQUNsQiwyRkFBaUI7Z0JBQ2pCLGdGQUFlO2dCQUNmLCtFQUFhO2dCQUNiLGtGQUFtQjthQUNwQjtZQUNELE9BQU8sRUFBRTtnQkFDUCx1RUFBYTtnQkFDYixxRUFBZ0I7Z0JBQ2hCLDREQUFZO2FBQ2I7WUFDRCxTQUFTLEVBQUUsRUFBRTtZQUNiLFNBQVMsRUFBRSxDQUFDLG1FQUFZLENBQUM7WUFDekIsT0FBTyxFQUFFLENBQUMsOERBQWdCLENBQUM7U0FDNUIsQ0FBQztRQUNGOztVQUVFO09BQ1csU0FBUyxDQUFJO0lBQUQsZ0JBQUM7Q0FBQTtBQUFKOzs7Ozs7OztBQzNDdEIsb2JBQW9iLGtDQUFrQyxzQ0FBc0Msb0NBQW9DLDZKQUE2Siw2REFBNkQsTUFBTSxrRkFBa0YsNERBQTRELE1BQU0sNElBQTRJLHdEQUF3RCxtRkFBbUYsK0NBQStDLG1GQUFtRixvQ0FBb0MscUc7Ozs7Ozs7QUNBajFDLDRLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0E0RjtBQVE1RjtJQVFFO1FBTkEsZUFBVSxHQUFHLEtBQUssQ0FBQztJQU1ILENBQUM7SUFFakIsb0NBQVEsR0FBUjtJQUVBLENBQUM7SUFUUTtRQUFSLDJEQUFLLEVBQUU7OzJEQUF1QjtJQUN0QjtRQUFSLDJEQUFLLEVBQUU7O3dEQUFtQjtJQUNsQjtRQUFSLDJEQUFLLEVBQUU7O3dEQUFtQjtJQUNsQjtRQUFSLDJEQUFLLEVBQUU7O3dEQUFtQjtJQU5oQixpQkFBaUI7UUFMN0IsK0RBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxjQUFjOzs7U0FHekIsQ0FBQzs7T0FDVyxpQkFBaUIsQ0FhM0I7SUFBRCx3QkFBQztDQUFBO0FBYjJCOzs7Ozs7OztBQ1I5Qix1Uzs7Ozs7OztBQ0FBLDRLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FvRTtBQUNEO0FBQ1I7QUFHc0I7QUE4QmpGO0lBYUUsdUJBQW9CLE9BQXVCLEVBQVUsVUFBc0I7UUFBdkQsWUFBTyxHQUFQLE9BQU8sQ0FBZ0I7UUFBVSxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBVDNFLGNBQVMsR0FBRyxJQUFJLENBQUM7UUFLakIsbUJBQWMsR0FBRyxFQUFFLENBQUM7UUFDcEIsV0FBTSxHQUFHLEtBQUssQ0FBQztRQUNmLFVBQUssR0FBRyxNQUFNLENBQUM7SUFFZ0UsQ0FBQztJQUVoRixnQ0FBUSxHQUFSO1FBQUEsaUJBaUJDO1FBaEJDLFdBQVc7UUFDWCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDOUIsMEJBQTBCO1FBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQzthQUNyRCxTQUFTLENBQUMsVUFBQyxHQUFHO1lBQ2IsS0FBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUM7WUFFbkIsbUNBQW1DO1lBQ25DLEtBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7WUFFaEYsV0FBVztZQUNYLEtBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUVyRixjQUFjO1lBQ2QsS0FBSSxDQUFDLGNBQWMsR0FBRyxLQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQzNELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELGdDQUFRLEdBQVI7UUFDQSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBcENRO1FBQVIsMkRBQUssRUFBRTs7bURBQWU7SUFDZDtRQUFSLDJEQUFLLEVBQUU7O21EQUFlO0lBQ2Q7UUFBUiwyREFBSyxFQUFFOzsrQ0FBYztJQUhYLGFBQWE7UUE1QnpCLCtEQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsVUFBVTs7O1lBR3BCLFVBQVUsRUFBRTtnQkFDVixtRUFBTyxDQUFDLGNBQWMsRUFBRTtvQkFDeEIsaUVBQUssQ0FBQyxRQUFRLEVBQUUsaUVBQUssQ0FBQzt3QkFDcEIsTUFBTSxFQUFFLE9BQU87d0JBQ2YsS0FBSyxFQUFFLEtBQUs7cUJBQ2IsQ0FBQyxDQUFDO29CQUNILDBCQUEwQjtvQkFDMUIscUJBQXFCO29CQUNyQixrQkFBa0I7b0JBQ2xCLE9BQU87b0JBQ1AsaUVBQUssQ0FBQyxZQUFZLEVBQUUsaUVBQUssQ0FBQzt3QkFDeEIsU0FBUyxFQUFFLGdCQUFnQjtxQkFDNUIsQ0FBQyxDQUFDO29CQUNILGlFQUFLLENBQUMsWUFBWSxFQUFFLGlFQUFLLENBQUM7d0JBQ3hCLFNBQVMsRUFBRSxjQUFjO3FCQUMxQixDQUFDLENBQUM7b0JBQ0gsc0VBQVUsQ0FBQyxrQkFBa0IsRUFBRSxtRUFBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO29CQUM1QyxzRUFBVSxDQUFDLGtCQUFrQixFQUFFLG1FQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQzVDLHNFQUFVLENBQUMsMEJBQTBCLEVBQUUsbUVBQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDcEQsc0VBQVUsQ0FBQywwQkFBMEIsRUFBRSxtRUFBTyxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUNwRCxDQUFDO2FBQ0g7U0FDRixDQUFDO3lDQWU2QixnRkFBYyxFQUFzQix3RUFBVTtPQWJoRSxhQUFhLENBc0N6QjtJQUFELG9CQUFDO0NBQUE7QUF0Q3lCOzs7Ozs7OztBQ25DMUIscUhBQXFILHVEQUF1RCx1QkFBdUIsMENBQTBDLGdDQUFnQyxzTUFBc00sd0JBQXdCLE1BQU0sZ0NBQWdDLHlCQUF5QixNQUFNLHlDOzs7Ozs7O0FDQWhqQix3aEI7Ozs7Ozs7QUNBQSw0Szs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBNkU7QUFLN0UsSUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFPbkM7SUFjRTtRQUFBLGlCQUdDO1FBRkMsSUFBSSxDQUFDLElBQUksR0FBRyxVQUFVLENBQUMsR0FBRyxDQUN4QixVQUFDLENBQUMsSUFBSyxZQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFqQixDQUFpQixDQUFDLENBQUM7SUFDOUIsQ0FBQztJQUVELGtHQUFrRztJQUNsRyxnQ0FBUSxHQUFSO1FBQUEsaUJBTUM7UUFMQyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDcEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBQyxJQUFLLFlBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQWxCLENBQWtCLENBQUMsQ0FBQztZQUM1RCxJQUFJLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsVUFBQyxDQUFDLElBQUssWUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBbkIsQ0FBbUIsQ0FBQyxDQUFDO1lBQzlELElBQUksQ0FBQyxRQUFRLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxVQUFDLENBQUMsSUFBSyxZQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFoQixDQUFnQixDQUFDLENBQUM7U0FDekQ7SUFDSCxDQUFDO0lBRUEsaUNBQVMsR0FBVCxVQUFVLEdBQUc7UUFDWCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUM3QyxPQUFPLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztJQUMvQixDQUFDO0lBRUQsa0NBQVUsR0FBVixVQUFXLEdBQUc7UUFDWCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQztJQUNuRSxDQUFDO0lBRUQsbUNBQVcsR0FBWCxVQUFZLEdBQUc7UUFDYixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQztJQUNqRSxDQUFDO0lBRUQsZ0NBQVEsR0FBUixVQUFTLEdBQUc7UUFDVixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUNoRixDQUFDO0lBekNRO1FBQVIsMkRBQUssRUFBRTs7c0RBQXNCO0lBSG5CLGFBQWE7UUFMekIsK0RBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxVQUFVOzs7U0FHckIsQ0FBQzs7T0FDVyxhQUFhLENBaUR6QjtJQUFELG9CQUFDO0NBQUE7QUFqRHlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWitCO0FBQ1U7QUFRbkU7SUFNRSw2QkFBb0IsT0FBdUI7UUFBdkIsWUFBTyxHQUFQLE9BQU8sQ0FBZ0I7UUFDekMsb0JBQW9CO1FBQ3BCLGdCQUFnQjtRQUNoQixrQkFBa0I7UUFDbEIsb0JBQW9CO0lBQ3RCLENBQUM7SUFFRCxzQ0FBUSxHQUFSO0lBQ0EsQ0FBQztJQWJRO1FBQVIsMkRBQUssRUFBRTs7cURBQW9CO0lBQ25CO1FBQVIsMkRBQUssRUFBRTs7bURBQWtCO0lBQ2pCO1FBQVIsMkRBQUssRUFBRTs7b0RBQW1CO0lBQ2xCO1FBQVIsMkRBQUssRUFBRTs7cURBQW9CO0lBSmpCLG1CQUFtQjtRQU4vQiwrREFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLGdCQUFnQjs7O1NBRzNCLENBQUM7eUNBUTZCLGdGQUFjO09BTmhDLG1CQUFtQixDQWUvQjtJQUFELDBCQUFDO0NBQUE7QUFmK0I7Ozs7Ozs7O0FDVGhDLGdZOzs7Ozs7O0FDQUEsNEs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQXlEO0FBT3pEO0lBSUU7UUFGUyxjQUFTLEdBQUcsSUFBSSxDQUFDO0lBRVYsQ0FBQztJQUVqQixxQ0FBUSxHQUFSO0lBQ0EsQ0FBQztJQUxRO1FBQVIsMkRBQUssRUFBRTs7eURBQWtCO0lBRmYsa0JBQWtCO1FBTDlCLCtEQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsZ0JBQWdCOzs7U0FHM0IsQ0FBQzs7T0FDVyxrQkFBa0IsQ0FTOUI7SUFBRCx5QkFBQztDQUFBO0FBVDhCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BZO0FBQ3lCO0FBRXpCO0FBTTNDO0lBRUUsb0JBQW9CLElBQWdCO1FBQWhCLFNBQUksR0FBSixJQUFJLENBQVk7SUFBSSxDQUFDO0lBQ3pDLHdCQUF3QjtJQUN4QiwrSUFBK0k7SUFDL0ksZ0NBQWdDO0lBQ2hDLElBQUk7SUFFSiwrQkFBVSxHQUFWLFVBQVcsR0FBRyxFQUFFLEdBQUc7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDakIsMkdBQXlHLEdBQUcsU0FBSSxHQUFLLENBQUM7YUFDdEgsSUFBSSxDQUFDLDBEQUFHLENBQUMsVUFBQyxHQUFZLElBQUssVUFBRyxFQUFILENBQUcsQ0FBQyxDQUFDLENBQUM7SUFDdEMsQ0FBQztJQVpVLFVBQVU7UUFIdEIsZ0VBQVUsQ0FBQztZQUNWLFVBQVUsRUFBRSxNQUFNO1NBQ25CLENBQUM7eUNBRzBCLCtEQUFVO09BRnpCLFVBQVUsQ0FjdEI7SUFBRCxpQkFBQztDQUFBO0FBZHNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1Q4QjtBQUNoQjtBQUVyQyxJQUFJLE9BQU8sR0FBRyxJQUFJLDhDQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7QUFLckM7SUFLRTtRQUhPLGNBQVMsR0FBRyxJQUFJLE9BQU8sQ0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQzVDLGNBQVMsR0FBRyxPQUFPLENBQUM7SUFFWCxDQUFDO0lBRWpCLGdDQUFPLEdBQVAsVUFBUSxJQUFJO1FBQ1YsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBVFUsY0FBYztRQUgxQixnRUFBVSxDQUFDO1lBQ1YsVUFBVSxFQUFFLE1BQU07U0FDbkIsQ0FBQzs7T0FDVyxjQUFjLENBd0MxQjtJQUFELHFCQUFDO0NBQUE7QUF4QzBCOzs7Ozs7OztBQ1IzQix5VkFBeVYsSUFBSSxxRDs7Ozs7OztBQ0E3Viw0Szs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQXlEO0FBQ1U7QUFFbkUsSUFBTSxVQUFVLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFRbkM7SUFLRSx5QkFBb0IsT0FBdUI7UUFBdkIsWUFBTyxHQUFQLE9BQU8sQ0FBZ0I7SUFFMUMsQ0FBQztJQUVGLGtDQUFRLEdBQVI7UUFBQSxpQkFNQztRQUpDLFVBQVUsQ0FBQztZQUNULEtBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFJLENBQUMsRUFBRSxFQUFFLEtBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3JFLEtBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2hDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNULENBQUM7SUFiUTtRQUFSLDJEQUFLLEVBQUU7O2lEQUFjO0lBQ2I7UUFBUiwyREFBSyxFQUFFOzsrQ0FBUztJQUhOLGVBQWU7UUFOM0IsK0RBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxZQUFZOzs7U0FHdkIsQ0FBQzt5Q0FPNkIsZ0ZBQWM7T0FMaEMsZUFBZSxDQWlCM0I7SUFBRCxzQkFBQztDQUFBO0FBakIyQjs7Ozs7Ozs7Ozs7Ozs7QUNSNUIsT0FBTyxFQUFFLHNCQUFTLENBQUUsMEVBQTRCOzs7Ozs7Ozs7Ozs7Ozs7OztBQUVoRCxjQUFnRjtBQUNOO0FBQzFFLHNEQUE2SDtBQUM3SCx3QkFBeUU7QUFDekUsU0FBd0U7QUFDeEUsUUFBbUY7QUFDbkYsWUFBeUQiLCJmaWxlIjoiYnVuZGxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiZnVuY3Rpb24gd2VicGFja0VtcHR5QXN5bmNDb250ZXh0KHJlcSkge1xuXHQvLyBIZXJlIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKSBpcyB1c2VkIGluc3RlYWQgb2YgbmV3IFByb21pc2UoKSB0byBwcmV2ZW50XG5cdC8vIHVuY2F1Z2h0IGV4Y2VwdGlvbiBwb3BwaW5nIHVwIGluIGRldnRvb2xzXG5cdHJldHVybiBQcm9taXNlLnJlc29sdmUoKS50aGVuKGZ1bmN0aW9uKCkge1xuXHRcdHZhciBlID0gbmV3IEVycm9yKFwiQ2Fubm90IGZpbmQgbW9kdWxlICdcIiArIHJlcSArIFwiJ1wiKTtcblx0XHRlLmNvZGUgPSAnTU9EVUxFX05PVF9GT1VORCc7XG5cdFx0dGhyb3cgZTtcblx0fSk7XG59XG53ZWJwYWNrRW1wdHlBc3luY0NvbnRleHQua2V5cyA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gW107IH07XG53ZWJwYWNrRW1wdHlBc3luY0NvbnRleHQucmVzb2x2ZSA9IHdlYnBhY2tFbXB0eUFzeW5jQ29udGV4dDtcbm1vZHVsZS5leHBvcnRzID0gd2VicGFja0VtcHR5QXN5bmNDb250ZXh0O1xud2VicGFja0VtcHR5QXN5bmNDb250ZXh0LmlkID0gXCIuLi8kJF9sYXp5X3JvdXRlX3Jlc291cmNlIGxhenkgcmVjdXJzaXZlXCI7IiwiZ2xvYmFsLnJlZ2lzdGVyTW9kdWxlKFwifkBuYXRpdmVzY3JpcHQvdGhlbWUvY3NzL2NvcmUuY3NzXCIsICgpID0+IHJlcXVpcmUoXCIhbmF0aXZlc2NyaXB0LWRldi13ZWJwYWNrL2NzczJqc29uLWxvYWRlcj91c2VGb3JJbXBvcnRzIUBuYXRpdmVzY3JpcHQvdGhlbWUvY3NzL2NvcmUuY3NzXCIpKTtcbmdsb2JhbC5yZWdpc3Rlck1vZHVsZShcIkBuYXRpdmVzY3JpcHQvdGhlbWUvY3NzL2NvcmUuY3NzXCIsICgpID0+IHJlcXVpcmUoXCIhbmF0aXZlc2NyaXB0LWRldi13ZWJwYWNrL2NzczJqc29uLWxvYWRlcj91c2VGb3JJbXBvcnRzIUBuYXRpdmVzY3JpcHQvdGhlbWUvY3NzL2NvcmUuY3NzXCIpKTtcbmdsb2JhbC5yZWdpc3Rlck1vZHVsZShcIn5AbmF0aXZlc2NyaXB0L3RoZW1lL2Nzcy9ibHVlLmNzc1wiLCAoKSA9PiByZXF1aXJlKFwiIW5hdGl2ZXNjcmlwdC1kZXYtd2VicGFjay9jc3MyanNvbi1sb2FkZXI/dXNlRm9ySW1wb3J0cyFAbmF0aXZlc2NyaXB0L3RoZW1lL2Nzcy9ibHVlLmNzc1wiKSk7XG5nbG9iYWwucmVnaXN0ZXJNb2R1bGUoXCJAbmF0aXZlc2NyaXB0L3RoZW1lL2Nzcy9ibHVlLmNzc1wiLCAoKSA9PiByZXF1aXJlKFwiIW5hdGl2ZXNjcmlwdC1kZXYtd2VicGFjay9jc3MyanNvbi1sb2FkZXI/dXNlRm9ySW1wb3J0cyFAbmF0aXZlc2NyaXB0L3RoZW1lL2Nzcy9ibHVlLmNzc1wiKSk7bW9kdWxlLmV4cG9ydHMgPSB7XCJ0eXBlXCI6XCJzdHlsZXNoZWV0XCIsXCJzdHlsZXNoZWV0XCI6e1wicnVsZXNcIjpbe1widHlwZVwiOlwiaW1wb3J0XCIsXCJpbXBvcnRcIjpcIlxcXCJ+QG5hdGl2ZXNjcmlwdC90aGVtZS9jc3MvY29yZS5jc3NcXFwiXCJ9LHtcInR5cGVcIjpcImltcG9ydFwiLFwiaW1wb3J0XCI6XCJcXFwifkBuYXRpdmVzY3JpcHQvdGhlbWUvY3NzL2JsdWUuY3NzXFxcIlwifSx7XCJ0eXBlXCI6XCJjb21tZW50XCIsXCJjb21tZW50XCI6XCIgUGxhY2UgYW55IENTUyBydWxlcyB5b3Ugd2FudCB0byBhcHBseSBvbiBib3RoIGlPUyBhbmQgQW5kcm9pZCBoZXJlLlxcblRoaXMgaXMgd2hlcmUgdGhlIHZhc3QgbWFqb3JpdHkgb2YgeW91ciBDU1MgY29kZSBnb2VzLiBcIn1dLFwicGFyc2luZ0Vycm9yc1wiOltdfX07O1xuICAgIGlmIChtb2R1bGUuaG90KSB7XG4gICAgICAgIG1vZHVsZS5ob3QuYWNjZXB0KCk7XG4gICAgICAgIG1vZHVsZS5ob3QuZGlzcG9zZSgoKSA9PiB7XG4gICAgICAgICAgICBnbG9iYWwuaG1yUmVmcmVzaCh7IHR5cGU6ICdzdHlsZScsIHBhdGg6ICcuL2FwcC5jc3MnIH0pO1xuICAgICAgICB9KVxuICAgIH1cbiIsIm1vZHVsZS5leHBvcnRzID0gXCI8IS0tIGh0dHBzOi8vZG9jcy5uYXRpdmVzY3JpcHQub3JnL2FuZ3VsYXIvY29yZS1jb25jZXB0cy9hbmd1bGFyLW5hdmlnYXRpb24uaHRtbCNwYWdlLXJvdXRlci1vdXRsZXQgLS0+XFxuPHBhZ2Utcm91dGVyLW91dGxldD48L3BhZ2Utcm91dGVyLW91dGxldD5cXG48TGFiZWwgdGV4dD1cXFwibWFpbiB2aWV3IHdvcmtzXFxcIj48L0xhYmVsPlxcbjwhLS0gPFN0YWNrTGF5b3V0PlxcbjxhcHAtbWFpbj48L2FwcC1tYWluPlxcbjwvU3RhY2tMYXlvdXQ+IC0tPlxcblwiIiwiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC1yb290JyxcbiAgdGVtcGxhdGVVcmw6ICcuL2FwcC5jb21wb25lbnQuaHRtbCcsXG59KVxuXG5leHBvcnQgY2xhc3MgQXBwQ29tcG9uZW50IHsgfVxuIiwiaW1wb3J0IHsgTmdNb2R1bGUsIE5PX0VSUk9SU19TQ0hFTUEgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdE1vZHVsZSB9IGZyb20gJ25hdGl2ZXNjcmlwdC1hbmd1bGFyL25hdGl2ZXNjcmlwdC5tb2R1bGUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IEJyb3dzZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7IEh0dHBDbGllbnRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5cbmltcG9ydCB7IEFwcENvbXBvbmVudCB9IGZyb20gJ0BzcmMvYXBwL2FwcC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTWFpbkNvbXBvbmVudCB9IGZyb20gJ0BzcmMvYXBwL21haW4vbWFpbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgUHJlTG9hZGVyQ29tcG9uZW50IH0gZnJvbSAnQHNyYy9hcHAvcHJlLWxvYWRlci9wcmUtbG9hZGVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEZXRhaWxlZENvbXBvbmVudCB9IGZyb20gJ0BzcmMvYXBwL21haW4vZGV0YWlsZWQvZGV0YWlsZWQuY29tcG9uZW50JztcbmltcG9ydCB7IFNreWNvbkNvbXBvbmVudCB9IGZyb20gJ0BzcmMvYXBwL3NreWNvbi9za3ljb24uY29tcG9uZW50JztcbmltcG9ydCB7IFdlZWtDb21wb25lbnQgfSBmcm9tICdAc3JjL2FwcC9tYWluL3dlZWsvd2Vlay5jb21wb25lbnQnO1xuaW1wb3J0IHsgV2Vla09iamVjdENvbXBvbmVudCB9IGZyb20gJ0BzcmMvYXBwL21haW4vd2Vlay93ZWVrLm1vZGVsJztcblxuXG4vLyBVbmNvbW1lbnQgYW5kIGFkZCB0byBOZ01vZHVsZSBpbXBvcnRzIGlmIHlvdSBuZWVkIHRvIHVzZSB0d28td2F5IGJpbmRpbmdcbi8vIGltcG9ydCB7IE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlIH0gZnJvbSAnbmF0aXZlc2NyaXB0LWFuZ3VsYXIvZm9ybXMnO1xuXG4vLyBVbmNvbW1lbnQgYW5kIGFkZCB0byBOZ01vZHVsZSBpbXBvcnRzICBpZiB5b3UgbmVlZCB0byB1c2UgdGhlIEhUVFAgd3JhcHBlclxuLy8gaW1wb3J0IHsgTmF0aXZlU2NyaXB0SHR0cENsaWVudE1vZHVsZSB9IGZyb20gJ25hdGl2ZXNjcmlwdC1hbmd1bGFyL2h0dHAtY2xpZW50JztcblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgQXBwQ29tcG9uZW50LFxuICAgIE1haW5Db21wb25lbnQsXG4gICAgUHJlTG9hZGVyQ29tcG9uZW50LFxuICAgIERldGFpbGVkQ29tcG9uZW50LFxuICAgIFNreWNvbkNvbXBvbmVudCxcbiAgICBXZWVrQ29tcG9uZW50LFxuICAgIFdlZWtPYmplY3RDb21wb25lbnRcbiAgXSxcbiAgaW1wb3J0czogW1xuICAgIEJyb3dzZXJNb2R1bGUsXG4gICAgSHR0cENsaWVudE1vZHVsZSxcbiAgICBDb21tb25Nb2R1bGVcbiAgXSxcbiAgcHJvdmlkZXJzOiBbXSxcbiAgYm9vdHN0cmFwOiBbQXBwQ29tcG9uZW50XSxcbiAgc2NoZW1hczogW05PX0VSUk9SU19TQ0hFTUFdXG59KVxuLypcblBhc3MgeW91ciBhcHBsaWNhdGlvbiBtb2R1bGUgdG8gdGhlIGJvb3RzdHJhcE1vZHVsZSBmdW5jdGlvbiBsb2NhdGVkIGluIG1haW4udHMgdG8gc3RhcnQgeW91ciBhcHBcbiovXG5leHBvcnQgY2xhc3MgQXBwTW9kdWxlIHsgfVxuIiwibW9kdWxlLmV4cG9ydHMgPSBcIjxTdGFja0xheW91dD5cXG4gIDxMYWJlbCB0ZXh0PVxcXCJkZXRhaWxlZCB3b3Jrc1xcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVGhpcyBpcyBhIG1pZ3JhdGVkIGNvbXBvbmVudFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVXBkYXRlIGl0IHRvIHByb3ZpZGUgdGhlIFVJIGVsZW1lbnRzIHJlcXVpcmVkIGluIHlvdXIgbW9iaWxlIGFwcFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuPC9TdGFja0xheW91dD5cXG5cXG48IS0tXFxuT3JpZ2luYWwgV2ViIHRlbXBsYXRlOlxcblxcblxcbjxkaXYgY2xhc3M9XFxcImNvbnRhaW5lclxcXCI+XFxuICA8ZGl2IGNsYXNzPVxcXCJ0b2RheS1oZWFkXFxcIj5cXG4gICAgPGgyIGNsYXNzPVxcXCJ0ZXh0LWNlbnRlclxcXCI+Q29uZGl0aW9ucyBmb3Ige3t0b2RheURhdGUgfCBkYXRlOidNTU1NIGRkLCB5eXl5J319PC9oMj5cXG4gICAgPHAgY2xhc3M9XFxcInRleHQtY2VudGVyXFxcIj57e2RhaWx5V2VhdGhlci5kYWlseS5kYXRhWzBdLnN1bW1hcnl9fTwvcD5cXG4gIDwvZGl2PlxcbiAgPGRpdiBjbGFzcz1cXFwidG9kYXktY29uZGl0aW9uc1xcXCI+XFxuICAgIDxkaXYgY2xhc3M9XFxcImNvbmRpdGlvbi1ibG9ja1xcXCI+XFxuICAgICAgPGg0PkhpZ2ggLyBMb3c8L2g0PlxcbiAgICAgIDxkaXYgY2xhc3M9XFxcInRlbXBcXFwiPlxcbiAgICAgICAgPHA+e3tkYWlseVdlYXRoZXIuZGFpbHkuZGF0YVswXS50ZW1wZXJhdHVyZUhpZ2ggfCBudW1iZXI6JzEuMC0wJ319JiMxNzY7PC9wPlxcbiAgICAgICAgPGkgY2xhc3M9XFxcImZhcyBmYS1hcnJvdy11cFxcXCI+PC9pPlxcbiAgICAgICAgPHA+IC8gPC9wPlxcbiAgICAgICAgPHA+e3tkYWlseVdlYXRoZXIuZGFpbHkuZGF0YVswXS50ZW1wZXJhdHVyZUxvdyB8IG51bWJlcjonMS4wLTAnfX0mIzE3Njs8L3A+XFxuICAgICAgICA8aSBjbGFzcz1cXFwiZmFzIGZhLWFycm93LWRvd25cXFwiPjwvaT5cXG4gICAgPC9kaXY+XFxuICA8L2Rpdj5cXG4gIDxkaXYgY2xhc3M9XFxcImNvbmRpdGlvbi1ibG9ja1xcXCI+XFxuICAgIDxoND5QcmVjaXAgJTwvaDQ+XFxuICAgIDxwPnt7ZGFpbHlXZWF0aGVyLmRhaWx5LmRhdGFbMF0ucHJlY2lwUHJvYmFiaWxpdHkgfCBwZXJjZW50fX08L3A+XFxuICA8L2Rpdj5cXG4gIDxkaXYgY2xhc3M9XFxcImNvbmRpdGlvbi1ibG9ja1xcXCI+XFxuICAgIDxoND5IdW1pZGl0eTwvaDQ+XFxuICAgIDxwPnt7ZGFpbHlXZWF0aGVyLmRhaWx5LmRhdGFbMF0uaHVtaWRpdHkgfCBwZXJjZW50fX08L3A+XFxuICA8L2Rpdj5cXG4gIDxkaXYgY2xhc3M9XFxcImNvbmRpdGlvbi1ibG9ja1xcXCI+XFxuICAgIDxoND5VViBJbmRleDwvaDQ+XFxuICAgIDxwPnt7ZGFpbHlXZWF0aGVyLmRhaWx5LmRhdGFbMF0udXZJbmRleH19PC9wPlxcbiAgPC9kaXY+XFxuICA8L2Rpdj5cXG4gIDxhcHAtd2Vla1xcbiAgW3dlZWtXZWF0aGVyXT0nZGFpbHlXZWF0aGVyJz5cXG4gIDwvYXBwLXdlZWs+XFxuPC9kaXY+XFxuXFxuLS0+XCIiLCJtb2R1bGUuZXhwb3J0cyA9IFwiLypcXG5BZGQgeW91ciBOYXRpdmVTY3JpcHQgc3BlY2lmaWMgc3R5bGVzIGhlcmUuXFxuVG8gbGVhcm4gbW9yZSBhYm91dCBzdHlsaW5nIGluIE5hdGl2ZVNjcmlwdCBzZWU6XFxuaHR0cHM6Ly9kb2NzLm5hdGl2ZXNjcmlwdC5vcmcvYW5ndWxhci91aS9zdHlsaW5nXFxuKi9cXG5cIiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBFbGVtZW50UmVmLCBJbmplY3QsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBXZWF0aGVyIH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy93ZWF0aGVyJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLWRldGFpbGVkJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2RldGFpbGVkLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vZGV0YWlsZWQuY29tcG9uZW50LnNjc3MnXVxufSlcbmV4cG9ydCBjbGFzcyBEZXRhaWxlZENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgdG9kYXlHcmFwaCA9IGZhbHNlO1xuICBASW5wdXQoKSBkYWlseVdlYXRoZXI6IFdlYXRoZXI7XG4gIEBJbnB1dCgpIGRldGFpbExhdDogbnVtYmVyO1xuICBASW5wdXQoKSBkZXRhaWxMbmc6IG51bWJlcjtcbiAgQElucHV0KCkgdG9kYXlEYXRlOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoKSB7IH1cblxuICBuZ09uSW5pdCgpe1xuXG4gIH1cbiAgfVxuXG5cbiIsIm1vZHVsZS5leHBvcnRzID0gXCI8U3RhY2tMYXlvdXQ+XFxuICA8TGFiZWwgdGV4dD1cXFwibWFpbiB3b3Jrc1xcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVGhpcyBpcyBhIG1pZ3JhdGVkIGNvbXBvbmVudFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVXBkYXRlIGl0IHRvIHByb3ZpZGUgdGhlIFVJIGVsZW1lbnRzIHJlcXVpcmVkIGluIHlvdXIgbW9iaWxlIGFwcFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuPC9TdGFja0xheW91dD5cXG5cXG5cIiIsIm1vZHVsZS5leHBvcnRzID0gXCIvKlxcbkFkZCB5b3VyIE5hdGl2ZVNjcmlwdCBzcGVjaWZpYyBzdHlsZXMgaGVyZS5cXG5UbyBsZWFybiBtb3JlIGFib3V0IHN0eWxpbmcgaW4gTmF0aXZlU2NyaXB0IHNlZTpcXG5odHRwczovL2RvY3MubmF0aXZlc2NyaXB0Lm9yZy9hbmd1bGFyL3VpL3N0eWxpbmdcXG4qL1xcblwiIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIElucHV0LCBPbkNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFNreWNvbnNTZXJ2aWNlIH0gZnJvbSAnQHNyYy9hcHAvc2VydmljZXMvc2t5Y29ucy5zZXJ2aWNlJztcbmltcG9ydCB7IEFwaVNlcnZpY2UgfSBmcm9tICdAc3JjL2FwcC9zZXJ2aWNlcy9hcGkuc2VydmljZSc7XG5pbXBvcnQgeyBjb21waWxlTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21waWxlcic7XG5pbXBvcnQgeyBXZWF0aGVyIH0gZnJvbSAnQHNyYy9hcHAvaW50ZXJmYWNlcy93ZWF0aGVyJztcbmltcG9ydCB7IHRyaWdnZXIsIHN0YXRlLCBzdHlsZSwgYW5pbWF0ZSwgdHJhbnNpdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtbWFpbicsXG4gIHRlbXBsYXRlVXJsOiAnLi9tYWluLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vbWFpbi5jb21wb25lbnQuc2NzcyddLFxuICBhbmltYXRpb25zOiBbXG4gICAgdHJpZ2dlcignZXhwYW5kU2hyaW5rJywgW1xuICAgIHN0YXRlKCdleHBhbmQnLCBzdHlsZSh7XG4gICAgICBoZWlnaHQ6ICc4MDBweCcsXG4gICAgICB3aWR0aDogJzkwJScsXG4gICAgfSkpLFxuICAgIC8vIHN0YXRlKCdzaHJpbmsnLCBzdHlsZSh7XG4gICAgLy8gICBoZWlnaHQ6ICc1MDBweCcsXG4gICAgLy8gICB3aWR0aDogJzY1JScsXG4gICAgLy8gfSkpLFxuICAgIHN0YXRlKCdleHBhbmRGbGlwJywgc3R5bGUoe1xuICAgICAgdHJhbnNmb3JtOiAncm90YXRlKDE4MGRlZyknLFxuICAgIH0pKSxcbiAgICBzdGF0ZSgnc2hyaW5rRmxpcCcsIHN0eWxlKHtcbiAgICAgIHRyYW5zZm9ybTogJ3JvdGF0ZSgwZGVnKSdcbiAgICB9KSksXG4gICAgdHJhbnNpdGlvbignZXhwYW5kID0+IHNocmluaycsIGFuaW1hdGUoMzAwKSksXG4gICAgdHJhbnNpdGlvbignc2hyaW5rID0+IGV4cGFuZCcsIGFuaW1hdGUoMzAwKSksXG4gICAgdHJhbnNpdGlvbignZXhwYW5kRmxpcCA9PiBzaHJpbmtGbGlwJywgYW5pbWF0ZSgzMDApKSxcbiAgICB0cmFuc2l0aW9uKCdzaHJpbmtGbGlwID0+IGV4cGFuZEZsaXAnLCBhbmltYXRlKDEwMDApKSxcbiAgICBdKSxcbiAgXVxufSlcblxuZXhwb3J0IGNsYXNzIE1haW5Db21wb25lbnQgaW1wbGVtZW50cyBPbkluaXR7XG4gIEBJbnB1dCgpIGZpbmFsTGF0OiBhbnk7XG4gIEBJbnB1dCgpIGZpbmFsTG5nOiBhbnk7XG4gIEBJbnB1dCgpIGNpdHk6IHN0cmluZztcbiAgc2hvd1RvZGF5ID0gdHJ1ZTtcbiAgd2VhdGhlcjogV2VhdGhlcjtcbiAgd2VhdGhlckljb246IHN0cmluZztcbiAgY3VycmVudFRlbXA6IGFueTtcbiAgY3VycmVudERhdGU6IGFueTtcbiAgY3VycmVudFN1bW1hcnkgPSAnJztcbiAgZXhwYW5kID0gZmFsc2U7XG4gIGdldElkID0gJyNza3knO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgc2t5Y29uczogU2t5Y29uc1NlcnZpY2UsIHByaXZhdGUgYXBpU2VydmljZTogQXBpU2VydmljZSkgeyB9XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgLy8gZ2V0IGRhdGVcbiAgICB0aGlzLmN1cnJlbnREYXRlID0gbmV3IERhdGUoKTtcbiAgICAvLyBnZXQgd2VhdGhlciBmcm9tIGNvb3Jkc1xuICAgIHRoaXMuYXBpU2VydmljZS5nZXRXZWF0aGVyKHRoaXMuZmluYWxMYXQsIHRoaXMuZmluYWxMbmcpXG4gICAgICAuc3Vic2NyaWJlKChyZXMpID0+IHtcbiAgICAgICAgdGhpcy53ZWF0aGVyID0gcmVzO1xuXG4gICAgICAgIC8vIHByaW50IGRhcmtza3kgYXBpIGdldCBpbiBjb25zb2xlXG4gICAgICAgIHRoaXMud2VhdGhlckljb24gPSB0aGlzLndlYXRoZXIuY3VycmVudGx5Lmljb24ucmVwbGFjZSgvLS9nLCAnXycpLnRvVXBwZXJDYXNlKCk7XG5cbiAgICAgICAgLy8gZ2V0IHRlbXBcbiAgICAgICAgdGhpcy5jdXJyZW50VGVtcCA9IHRoaXMud2VhdGhlci5jdXJyZW50bHkuYXBwYXJlbnRUZW1wZXJhdHVyZS50b1N0cmluZygpLnNsaWNlKDAsIDIpO1xuXG4gICAgICAgIC8vIGdldCBzdW1tYXJ5XG4gICAgICAgIHRoaXMuY3VycmVudFN1bW1hcnkgPSB0aGlzLndlYXRoZXIuZGFpbHkuZGF0YVswXS5zdW1tYXJ5O1xuICAgICAgfSk7XG4gIH1cblxuICBpc0V4cGFuZCgpIHtcbiAgdGhpcy5leHBhbmQgPSAhdGhpcy5leHBhbmQ7XG4gIHRoaXMuc2hvd1RvZGF5ID0gIXRoaXMuc2hvd1RvZGF5O1xuICB9XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IFwiPGRpdiBjbGFzcz1cXFwid2Vlay1jb250YWluZXJcXFwiPlxcbiAgPGRpdiBjbGFzcz1cXFwid2Vlay1pdGVtLWNvbnRhaW5lclxcXCIgKm5nRm9yPVxcXCJsZXQgZGF0ZUl0ZW0gb2YgZGF0ZTsgbGV0IGkgPSBpbmRleFxcXCI+XFxuICAgIDxwIGNsYXNzPVxcXCJkYXRlIHRleHQtY2VudGVyXFxcIj57e2RhdGVbaV0gfCBkYXRlOidFRUVFJ319PC9wPlxcbiAgICA8cCBjbGFzcz1cXFwiZGF0ZSB0ZXh0LWNlbnRlclxcXCI+e3tkYXRlW2ldIHwgZGF0ZTonTU1NTSBkZCwgeXl5eSd9fTwvcD5cXG4gICAgPGFwcC1za3ljb24gKm5nSWY9J2ljb24nIFtpY29uXT1cXFwiaWNvbltpXVxcXCIgW2lkXT1cXFwiJyNza3ktJyArIGlcXFwiPlxcbiAgICA8L2FwcC1za3ljb24+XFxuICAgIDxwIGNsYXNzPVxcXCJ0ZXh0LWNlbnRlclxcXCI+SGlnaCAvIExvdzwvcD5cXG4gICAgPGRpdiBjbGFzcz1cXFwidGVtcC1mbGV4XFxcIj5cXG4gICAgICA8cCBjbGFzcz1cXFwidGVtcFxcXCI+e3toaVtpXSB8IG51bWJlcjonMS4wLTAnfX0mIzE3Njs8L3A+XFxuICAgICAgPHAgY2xhc3M9XFxcInRlbXBcXFwiPnt7bG93W2ldIHwgbnVtYmVyOicxLjAtMCd9fSYjMTc2OzwvcD5cXG4gICAgPC9kaXY+XFxuICA8L2Rpdj5cXG48L2Rpdj5cXG5cXG5cXG5cIiIsIm1vZHVsZS5leHBvcnRzID0gXCI8U3RhY2tMYXlvdXQ+XFxuICA8TGFiZWwgdGV4dD1cXFwid2VlayB3b3Jrc1xcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVGhpcyBpcyBhIG1pZ3JhdGVkIGNvbXBvbmVudFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVXBkYXRlIGl0IHRvIHByb3ZpZGUgdGhlIFVJIGVsZW1lbnRzIHJlcXVpcmVkIGluIHlvdXIgbW9iaWxlIGFwcFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuPC9TdGFja0xheW91dD5cXG5cXG48IS0tXFxuT3JpZ2luYWwgV2ViIHRlbXBsYXRlOlxcblxcbjxkaXYgY2xhc3M9XFxcIndlZWstd3JhcHBlclxcXCI+XFxuICA8aDI+NSBEYXkgRm9yZWNhc3Q8L2gyPlxcbiAgICA8YXBwLXdlZWstbW9kZWxcXG4gICAgW2RhdGVdPSdkYXlzJ1xcbiAgICBbaGldPSdkYXlzVGVtcEhpJ1xcbiAgICBbbG93XT0nZGF5c1RlbXBMb3cnXFxuICAgIFtpY29uXT0nZGF5c0ljb24nXFxuICAgID5cXG4gIDwvYXBwLXdlZWstbW9kZWw+XFxuPC9kaXY+XFxuXFxuLS0+XCIiLCJtb2R1bGUuZXhwb3J0cyA9IFwiLypcXG5BZGQgeW91ciBOYXRpdmVTY3JpcHQgc3BlY2lmaWMgc3R5bGVzIGhlcmUuXFxuVG8gbGVhcm4gbW9yZSBhYm91dCBzdHlsaW5nIGluIE5hdGl2ZVNjcmlwdCBzZWU6XFxuaHR0cHM6Ly9kb2NzLm5hdGl2ZXNjcmlwdC5vcmcvYW5ndWxhci91aS9zdHlsaW5nXFxuKi9cXG5cIiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbnB1dCwgT25DaGFuZ2VzLCBEb0NoZWNrIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1dlYXRoZXIsIERheUZvcmVjYXN0LCBXZWVrRGF5fSBmcm9tICcuLi8uLi9pbnRlcmZhY2VzL3dlYXRoZXInO1xuaW1wb3J0IHsgZm9ybWF0RGF0ZSwgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuXG5jb25zdCBkYXlzT2JqZWN0ID0gWzEsIDIsIDMsIDQsIDVdO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtd2VlaycsXG4gIHRlbXBsYXRlVXJsOiAnLi93ZWVrLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vd2Vlay5jb21wb25lbnQuc2NzcyddXG59KVxuZXhwb3J0IGNsYXNzIFdlZWtDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuXG4gIGZvcmVjYXN0czogRGF5Rm9yZWNhc3RbXTtcbiAgQElucHV0KCkgd2Vla1dlYXRoZXI6IFdlYXRoZXI7XG4gIGRheTogYW55O1xuICBkYXRlOiBEYXRlO1xuICB3ZWVrRGF5OiBXZWVrRGF5O1xuXG4gIGRheXM6IGFueVtdO1xuICBkYXlzVGVtcEhpOiBhbnlbXTtcbiAgZGF5c1RlbXBMb3c6IGFueVtdO1xuICBkYXlzSWNvbjogYW55O1xuXG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5kYXlzID0gZGF5c09iamVjdC5tYXAoXG4gICAgICAoaSkgPT4gdGhpcy53ZWVrRGF0ZXMoaSkpO1xuICB9XG5cbiAgLyogY2hlY2sgaWYgd2Vla1dlYXRoZXIgQElucHV0IGlzIGxvYWRlZCBpbiBjb21wb25lbnQgKGlzIHVuZGVmaW5lZCB3aGVuIGNhbGxlZCBpbiBjb25zdHJ1Y3RvcikgKi9cbiAgbmdPbkluaXQoKSB7XG4gICAgaWYgKHRoaXMud2Vla1dlYXRoZXIpIHtcbiAgICAgIHRoaXMuZGF5c1RlbXBIaSA9IGRheXNPYmplY3QubWFwKChfKSA9PiB0aGlzLndlZWtUZW1wSGkoXykpO1xuICAgICAgdGhpcy5kYXlzVGVtcExvdyA9IGRheXNPYmplY3QubWFwKChfKSA9PiB0aGlzLndlZWtUZW1wTG93KF8pKTtcbiAgICAgIHRoaXMuZGF5c0ljb24gPSBkYXlzT2JqZWN0Lm1hcCgoXykgPT4gdGhpcy53ZWVrSWNvbihfKSk7XG4gICAgfVxuICB9XG5cbiAgIHdlZWtEYXRlcyhkYXkpIHtcbiAgICAgdGhpcy5kYXRlID0gbmV3IERhdGUoKTtcbiAgICAgdGhpcy5kYXRlLnNldERhdGUodGhpcy5kYXRlLmdldERhdGUoKSArIGRheSk7XG4gICAgIHJldHVybiB0aGlzLmRheSA9IHRoaXMuZGF0ZTtcbiAgfVxuXG4gIHdlZWtUZW1wSGkoZGF5KXtcbiAgICAgcmV0dXJuIHRoaXMud2Vla1dlYXRoZXIuZGFpbHkuZGF0YVtkYXldLmFwcGFyZW50VGVtcGVyYXR1cmVIaWdoO1xuICB9XG5cbiAgd2Vla1RlbXBMb3coZGF5KXtcbiAgICByZXR1cm4gdGhpcy53ZWVrV2VhdGhlci5kYWlseS5kYXRhW2RheV0uYXBwYXJlbnRUZW1wZXJhdHVyZUxvdztcbiAgfVxuXG4gIHdlZWtJY29uKGRheSl7XG4gICAgcmV0dXJuIHRoaXMud2Vla1dlYXRoZXIuZGFpbHkuZGF0YVtkYXldLmljb24ucmVwbGFjZSgvLS9nLCAnXycpLnRvVXBwZXJDYXNlKCk7XG4gIH1cblxuXG5cblxufVxuIiwiaW1wb3J0IHsgSW5wdXQsIENvbXBvbmVudCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBTa3ljb25zU2VydmljZSB9IGZyb20gJ0BzcmMvYXBwL3NlcnZpY2VzL3NreWNvbnMuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2FwcC13ZWVrLW1vZGVsJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3dlZWstbW9kZWwuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3dlZWsuY29tcG9uZW50LnNjc3MnXVxufSlcblxuZXhwb3J0IGNsYXNzIFdlZWtPYmplY3RDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBASW5wdXQoKSBwdWJsaWMgZGF0ZTogYW55W107XG4gIEBJbnB1dCgpIHB1YmxpYyBoaTogYW55W107XG4gIEBJbnB1dCgpIHB1YmxpYyBsb3c6IGFueVtdO1xuICBASW5wdXQoKSBwdWJsaWMgaWNvbjogYW55W107XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBza3ljb25zOiBTa3ljb25zU2VydmljZSkge1xuICAgIC8vIHRoaXMuZGF0ZSA9IGRhdGU7XG4gICAgLy8gdGhpcy5oaSA9IGhpO1xuICAgIC8vIHRoaXMubG93ID0gbG93O1xuICAgIC8vIHRoaXMuaWNvbiA9IGljb247XG4gIH1cblxuICBuZ09uSW5pdCgpe1xuICB9XG59XG5cbiIsIm1vZHVsZS5leHBvcnRzID0gXCI8U3RhY2tMYXlvdXQ+XFxuICA8TGFiZWwgdGV4dD1cXFwicHJlLWxvYWRlciB3b3Jrc1xcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVGhpcyBpcyBhIG1pZ3JhdGVkIGNvbXBvbmVudFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVXBkYXRlIGl0IHRvIHByb3ZpZGUgdGhlIFVJIGVsZW1lbnRzIHJlcXVpcmVkIGluIHlvdXIgbW9iaWxlIGFwcFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuPC9TdGFja0xheW91dD5cXG5cXG48IS0tXFxuT3JpZ2luYWwgV2ViIHRlbXBsYXRlOlxcblxcbjxkaXYgY2xhc3M9XFxcImxvYWRlclxcXCI+R2V0dGluZyBXZWF0aGVyLi4uPC9kaXY+XFxuLS0+XCIiLCJtb2R1bGUuZXhwb3J0cyA9IFwiLypcXG5BZGQgeW91ciBOYXRpdmVTY3JpcHQgc3BlY2lmaWMgc3R5bGVzIGhlcmUuXFxuVG8gbGVhcm4gbW9yZSBhYm91dCBzdHlsaW5nIGluIE5hdGl2ZVNjcmlwdCBzZWU6XFxuaHR0cHM6Ly9kb2NzLm5hdGl2ZXNjcmlwdC5vcmcvYW5ndWxhci91aS9zdHlsaW5nXFxuKi9cXG5cIiIsImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdhcHAtcHJlLWxvYWRlcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9wcmUtbG9hZGVyLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vcHJlLWxvYWRlci5jb21wb25lbnQuc2NzcyddXG59KVxuZXhwb3J0IGNsYXNzIFByZUxvYWRlckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgQElucHV0KCkgbG9hZENoZWNrID0gdHJ1ZTtcblxuICBjb25zdHJ1Y3RvcigpIHsgfVxuXG4gIG5nT25Jbml0KCkge1xuICB9XG5cbn1cbiIsImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEh0dHBDbGllbnQsIEh0dHBDbGllbnRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24vaHR0cCc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBtYXAsIHRha2UgfSBmcm9tICdyeGpzL29wZXJhdG9ycyc7XG5pbXBvcnQgeyBXZWF0aGVyIH0gZnJvbSAnLi4vaW50ZXJmYWNlcy93ZWF0aGVyJztcblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCdcbn0pXG5leHBvcnQgY2xhc3MgQXBpU2VydmljZSB7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBodHRwOiBIdHRwQ2xpZW50KSB7IH1cbiAgLy8gZ2V0R29vZ2xlKGxhdCwgbG5nKSB7XG4gIC8vICAgcmV0dXJuIHRoaXMuaHR0cC5nZXQoYGh0dHBzOi8vbWFwcy5nb29nbGVhcGlzLmNvbS9tYXBzL2FwaS9nZW9jb2RlL2pzb24/bGF0bG5nPSR7bGF0fSwke2xuZ30ma2V5PUFJemFTeUJBUTA5SDZteDRyVzEwa0FybTVuUnBuLUlQVXFYTFpNZ2ApXG4gIC8vICAgICAucGlwZShtYXAoKHJlcykgPT4gcmVzKSk7XG4gIC8vIH1cblxuICBnZXRXZWF0aGVyKGxhdCwgbG5nKTogT2JzZXJ2YWJsZTxXZWF0aGVyPiB7XG4gICAgcmV0dXJuIHRoaXMuaHR0cC5nZXRcbiAgICAgIChgaHR0cHM6Ly9jb3JzLWFueXdoZXJlLmhlcm9rdWFwcC5jb20vaHR0cHM6Ly9hcGkuZGFya3NreS5uZXQvZm9yZWNhc3QvNThkYzc5NTRjMmEwNzI4NDIxZDY4YTNhODlmM2RjNTUvJHtsYXR9LCR7bG5nfWApXG4gICAgICAucGlwZShtYXAoKHJlczogV2VhdGhlcikgPT4gcmVzKSk7XG4gIH1cblxufVxuIiwiaW1wb3J0IHsgSW5qZWN0YWJsZSwgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCBTa3ljb25zTGlicmFyeSBmcm9tICdza3ljb25zJztcblxubGV0IFNreWNvbnMgPSBuZXcgU2t5Y29uc0xpYnJhcnkoe30pO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBTa3ljb25zU2VydmljZSB7XG5cbiAgcHVibGljIGZ1bmN0aW9ucyA9IG5ldyBTa3ljb25zKHsgY29sb3I6ICd3aGl0ZScgfSk7XG4gIHB1YmxpYyBjb25zdGFudHMgPSBTa3ljb25zO1xuXG4gIGNvbnN0cnVjdG9yKCkgeyB9XG5cbiAgZ2V0SWNvbihpY29uKSB7XG4gICAgcmV0dXJuIGljb247XG4gIH1cblxuICAvLyBnZXRJY29uKGljb24pIHtcbiAgLy8gICBzd2l0Y2ggKGljb24pIHtcbiAgLy8gICAgIGNhc2UgJ3JhaW4nOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuUkFJTjtcbiAgLy8gICAgIGNhc2UgJ3Nub3cnOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuU05PVztcbiAgLy8gICAgIGNhc2UgJ2ZvZyc6XG4gIC8vICAgICAgIHJldHVybiB0aGlzLmNvbnN0YW50cy5GT0c7XG4gIC8vICAgICBjYXNlICdjbGVhci1kYXknOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuQ0xFQVJfREFZO1xuICAvLyAgICAgY2FzZSAnY2xlYXItbmlnaHQnOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuQ0xFQVJfTklHSFQ7XG4gIC8vICAgICBjYXNlICdjbG91ZHknOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuQ0xPVURZO1xuICAvLyAgICAgY2FzZSAncGFydGx5LWNsb3VkeS1uaWdodCc6XG4gIC8vICAgICAgIHJldHVybiB0aGlzLmNvbnN0YW50cy5QQVJUTFlfQ0xPVURZX05JR0hUO1xuICAvLyAgICAgY2FzZSAncGFydGx5LWNsb3VkeS1kYXknOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuUEFSVExZX0NMT1VEWV9EQVk7XG4gIC8vICAgICBjYXNlICdzbm93JzpcbiAgLy8gICAgICAgcmV0dXJuIHRoaXMuY29uc3RhbnRzLlNOT1c7XG4gIC8vICAgICBjYXNlICdzbGVldCc6XG4gIC8vICAgICAgIHJldHVybiB0aGlzLmNvbnN0YW50cy5TTEVFVDtcbiAgLy8gICAgIGNhc2UgJ3dpbmQnOlxuICAvLyAgICAgICByZXR1cm4gdGhpcy5jb25zdGFudHMuV0lORDtcbiAgLy8gICAgIGRlZmF1bHQ6XG4gIC8vICAgICAgIHJldHVybiBpY29uO1xuICAvLyAgIH1cbiAgLy8gfVxuXG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IFwiPFN0YWNrTGF5b3V0PlxcbiAgPExhYmVsIHRleHQ9XFxcInNreWNvbiB3b3Jrc1xcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVGhpcyBpcyBhIG1pZ3JhdGVkIGNvbXBvbmVudFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuICA8TGFiZWwgdGV4dD1cXFwiVXBkYXRlIGl0IHRvIHByb3ZpZGUgdGhlIFVJIGVsZW1lbnRzIHJlcXVpcmVkIGluIHlvdXIgbW9iaWxlIGFwcFxcXCIgdGV4dFdyYXA9XFxcInRydWVcXFwiPjwvTGFiZWw+XFxuPC9TdGFja0xheW91dD5cXG5cXG48IS0tXFxuT3JpZ2luYWwgV2ViIHRlbXBsYXRlOlxcblxcblxcbjxjYW52YXMgaWQ9XFxcInt7aWR9fVxcXCIgaGVpZ2h0PVxcXCIzMDBcXFwiIHdpZHRoPVxcXCIzMDBcXFwiPjwvY2FudmFzPlxcblxcblxcblxcbi0tPlwiIiwibW9kdWxlLmV4cG9ydHMgPSBcIi8qXFxuQWRkIHlvdXIgTmF0aXZlU2NyaXB0IHNwZWNpZmljIHN0eWxlcyBoZXJlLlxcblRvIGxlYXJuIG1vcmUgYWJvdXQgc3R5bGluZyBpbiBOYXRpdmVTY3JpcHQgc2VlOlxcbmh0dHBzOi8vZG9jcy5uYXRpdmVzY3JpcHQub3JnL2FuZ3VsYXIvdWkvc3R5bGluZ1xcbiovXFxuXCIiLCJpbXBvcnQgeyBDb21wb25lbnQsIE9uSW5pdCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IFNreWNvbnNTZXJ2aWNlIH0gZnJvbSAnQHNyYy9hcHAvc2VydmljZXMvc2t5Y29ucy5zZXJ2aWNlJztcblxuY29uc3QgZGF5c09iamVjdCA9IFsxLCAyLCAzLCA0LCA1XTtcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnYXBwLXNreWNvbicsXG4gIHRlbXBsYXRlVXJsOiAnLi9za3ljb24uY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9za3ljb24uY29tcG9uZW50LnNjc3MnXVxufSlcblxuZXhwb3J0IGNsYXNzIFNreWNvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgQElucHV0KCkgaWNvbjogc3RyaW5nO1xuICBASW5wdXQoKSBpZDogYW55O1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgc2t5Y29uczogU2t5Y29uc1NlcnZpY2UpIHtcblxuICAgfVxuXG4gIG5nT25Jbml0KCkge1xuXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLnNreWNvbnMuZnVuY3Rpb25zLmFkZCh0aGlzLmlkLCB0aGlzLnNreWNvbnMuZ2V0SWNvbih0aGlzLmljb24pKTtcbiAgICAgIHRoaXMuc2t5Y29ucy5mdW5jdGlvbnMucGxheSgpO1xuICAgIH0sIC4xKTtcbiAgfVxuXG59XG4iLCIvLyB0aGlzIGltcG9ydCBzaG91bGQgYmUgZmlyc3QgaW4gb3JkZXIgdG8gbG9hZCBzb21lIHJlcXVpcmVkIHNldHRpbmdzIChsaWtlIGdsb2JhbHMgYW5kIHJlZmxlY3QtbWV0YWRhdGEpXG5pbXBvcnQgeyBwbGF0Zm9ybU5hdGl2ZVNjcmlwdER5bmFtaWMgfSBmcm9tICduYXRpdmVzY3JpcHQtYW5ndWxhci9wbGF0Zm9ybSc7XG5cbmltcG9ydCB7IEFwcE1vZHVsZSB9IGZyb20gJ0BzcmMvYXBwL2FwcC5tb2R1bGUnO1xuXG4vLyBBIHRyYWRpdGlvbmFsIE5hdGl2ZVNjcmlwdCBhcHBsaWNhdGlvbiBzdGFydHMgYnkgaW5pdGlhbGl6aW5nIGdsb2JhbCBvYmplY3RzLFxuLy8gc2V0dGluZyB1cCBnbG9iYWwgQ1NTIHJ1bGVzLCBjcmVhdGluZywgYW5kIG5hdmlnYXRpbmcgdG8gdGhlIG1haW4gcGFnZS5cbi8vIEFuZ3VsYXIgYXBwbGljYXRpb25zIG5lZWQgdG8gdGFrZSBjYXJlIG9mIHRoZWlyIG93biBpbml0aWFsaXphdGlvbjogbW9kdWxlcywgY29tcG9uZW50cywgZGlyZWN0aXZlcywgcm91dGVzLCBESSBwcm92aWRlcnMuXG4vLyBBIE5hdGl2ZVNjcmlwdCBBbmd1bGFyIGFwcCBuZWVkcyB0byBtYWtlIGJvdGggcGFyYWRpZ21zIHdvcmsgdG9nZXRoZXIsXG4vLyBzbyB3ZSBwcm92aWRlIGEgd3JhcHBlciBwbGF0Zm9ybSBvYmplY3QsIHBsYXRmb3JtTmF0aXZlU2NyaXB0RHluYW1pYyxcbi8vIHRoYXQgc2V0cyB1cCBhIE5hdGl2ZVNjcmlwdCBhcHBsaWNhdGlvbiBhbmQgY2FuIGJvb3RzdHJhcCB0aGUgQW5ndWxhciBmcmFtZXdvcmsuXG5wbGF0Zm9ybU5hdGl2ZVNjcmlwdER5bmFtaWMoKS5ib290c3RyYXBNb2R1bGUoQXBwTW9kdWxlKTtcbiJdLCJzb3VyY2VSb290IjoiIn0=